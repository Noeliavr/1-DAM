<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

    <xsl:output method="xml" indent="yes" encoding="UTF-8"
        doctype-system="cuenta_bancaria"/>
    <xsl:strip-space elements="*"/>

    <xsl:template match="/">
        <cuentas>
            <xsl:apply-templates select="banco/cuentas/cuenta"/>
        </cuentas>
    </xsl:template>

    <xsl:template match="cuenta">
        <cuenta id="{@id}">
            <titular>
                <nombre>
                    <xsl:value-of select="titular/nombreCompleto"/>
                </nombre>
                <nif>
                    <xsl:value-of select="titular/documento"/>
                </nif>
            </titular>
            <saldo>
                <xsl:value-of select="saldoActual"/>
            </saldo>
            <movimientos>
                <xsl:apply-templates select="movimientos/movimiento"/>
            </movimientos>
        </cuenta>
    </xsl:template>

    <xsl:template match="movimiento">
        <movimiento id="{concat('m', format-number(position(), '00'))}">
            <fecha>
                <xsl:value-of select="fecha"/>
            </fecha>
            <tipo>
                <xsl:value-of select="tipo"/>
            </tipo>
            <concepto>
                <xsl:value-of select="concepto"/>
            </concepto>
            <importe>
                <xsl:value-of select="importe"/>
            </importe>
        </movimiento>
    </xsl:template>

</xsl:stylesheet>
