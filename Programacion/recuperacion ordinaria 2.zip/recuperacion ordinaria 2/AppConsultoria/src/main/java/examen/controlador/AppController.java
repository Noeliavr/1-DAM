package examen.controlador;

public class AppController {
    
}
