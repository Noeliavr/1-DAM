package examen.vista;

public class ConsoleView {
    
}
